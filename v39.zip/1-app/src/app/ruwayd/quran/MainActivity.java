package app.ruwayd.quran;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.util.Base64;
import java.io.OutputStream;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final String BASE = "file:///android_asset/www/";
    private static final int REQ_MIC = 7;
    private static final int REQ_WEB_MIC = 8;
    private PermissionRequest pendingWeb;
    private WebView web;
    private FrameLayout root;
    private SpeechRecognizer recognizer;
    private int srRetry = 0;
    private volatile boolean wantListen = false;

    @Override
    protected void onCreate(Bundle state) {
        setTheme(R.style.AppTheme);
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // الحاوية تأخذ حواف النظام (شريط الحالة والتنقل) حشوًا، فيبقى المحتوى داخل المساحة الآمنة
        root = new FrameLayout(this);
        root.setFitsSystemWindows(true);
        root.setBackgroundColor(Color.parseColor("#F3F0EA"));
        web = new WebView(this);
        /* الضغطة المطوّلة تُترك لأزرار الصفحة (التحكّم السريع)، وتبقى على حالها في حقول الكتابة للّصق */
        web.setHapticFeedbackEnabled(false);
        web.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                WebView.HitTestResult r = web.getHitTestResult();
                return r == null || r.getType() != WebView.HitTestResult.EDIT_TEXT_TYPE;
            }
        });
        web.setBackgroundColor(Color.parseColor("#F3F0EA"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        // لتحميل تلاوة القارئ وتحليلها في «محاكاة القارئ»
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.addJavascriptInterface(new Bridge(), "Native");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        grantWebMic(request);
                    }
                });
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                return u == null || !u.toString().startsWith(BASE);
            }
        });
        if (state == null) {
            web.loadUrl(BASE + "index.html");
        } else {
            web.restoreState(state);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) {
            recognizer.destroy();
            recognizer = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.onBack&&window.onBack())?1:0", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if (!"1".equals(v)) {
                    finish();
                }
            }
        });
    }

    /* ---------- التسميع الصوتي ---------- */

    private void emit(String event, String data) {
        if (web == null) {
            return;
        }
        web.evaluateJavascript("window.onSpeech&&window.onSpeech(" + JSONObject.quote(event) + "," + JSONObject.quote(data == null ? "" : data) + ")", null);
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
                recognizer.setRecognitionListener(new Listener());
            }
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA");
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-SA");
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
            try {
                recognizer.cancel();
            } catch (RuntimeException ignored) {
            }
            recognizer.startListening(i);
        } catch (RuntimeException e) {
            emit("error", "5");
        }
    }

    /* تسجيل تلاوة المستخدم في «محاكاة القارئ»: الإذن لصفحة التطبيق المحلية فقط وللصوت فقط */
    private void grantWebMic(PermissionRequest request) {
        boolean audio = false;
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) {
                audio = true;
            }
        }
        Uri origin = request.getOrigin();
        if (!audio || origin == null || !"file".equals(origin.getScheme())) {
            request.deny();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
        } else {
            pendingWeb = request;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_WEB_MIC);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        if (code == REQ_WEB_MIC) {
            PermissionRequest p = pendingWeb;
            pendingWeb = null;
            if (p != null) {
                if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                    p.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                } else {
                    p.deny();
                }
            }
            return;
        }
        if (code != REQ_MIC) {
            return;
        }
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            startListening();
        } else {
            emit("denied", "");
        }
    }

    private static String join(ArrayList<String> list) {
        if (list == null || list.isEmpty()) {
            return "";
        }
        StringBuilder b = new StringBuilder();
        for (int k = 0; k < list.size(); k++) {
            if (k > 0) {
                b.append('|');
            }
            b.append(list.get(k));
        }
        return b.toString();
    }

    private class Listener implements RecognitionListener {
        @Override
        public void onReadyForSpeech(Bundle params) {
            srRetry = 0;
            emit("ready", "");
        }

        @Override
        public void onPartialResults(Bundle partial) {
            ArrayList<String> r = partial.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (r != null && !r.isEmpty()) {
                emit("partial", r.get(0));
            }
        }

        @Override
        public void onResults(Bundle results) {
            emit("final", join(results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)));
        }

        @Override
        public void onError(int error) {
            /* الخدمة مشغولة أو خطأ عابر عند إعادة الاستماع مباشرة: نعيد المحاولة بصمت */
            if ((error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) && srRetry < 2) {
                srRetry++;
                web.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (wantListen) {
                            startListening();
                        }
                    }
                }, 350);
                return;
            }
            emit("error", String.valueOf(error));
        }

        @Override
        public void onBeginningOfSpeech() {
        }

        @Override
        public void onRmsChanged(float rms) {
        }

        @Override
        public void onBufferReceived(byte[] buffer) {
        }

        @Override
        public void onEndOfSpeech() {
        }

        @Override
        public void onEvent(int type, Bundle params) {
        }
    }

    private class Bridge {
        @JavascriptInterface
        public boolean speechAvailable() {
            return SpeechRecognizer.isRecognitionAvailable(MainActivity.this);
        }

        @JavascriptInterface
        public void listen() {
            wantListen = true;
            web.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (wantListen) {
                        startListening();
                    }
                }
            }, 120);
        }

        @JavascriptInterface
        public void stopListen() {
            wantListen = false;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (recognizer != null) {
                        recognizer.cancel();
                    }
                }
            });
        }

        @JavascriptInterface
        public boolean saveImage(String base64, String name) {
            if (Build.VERSION.SDK_INT < 29) {
                return false;
            }
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                ContentValues v = new ContentValues();
                v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Certificates");
                android.net.Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                if (u == null) {
                    return false;
                }
                OutputStream out = getContentResolver().openOutputStream(u);
                if (out == null) {
                    return false;
                }
                out.write(data);
                out.close();
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText("ruwayd", text));
                    }
                }
            });
        }

        @JavascriptInterface
        public void setBars(final String color, final boolean dark) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    int c;
                    try {
                        c = Color.parseColor(color);
                    } catch (IllegalArgumentException e) {
                        return;
                    }
                    Window w = getWindow();
                    root.setBackgroundColor(c);
                    web.setBackgroundColor(c);
                    w.setStatusBarColor(c);
                    w.setNavigationBarColor(c);
                    if (Build.VERSION.SDK_INT >= 30) {
                        WindowInsetsController ic = w.getInsetsController();
                        if (ic != null) {
                            int both = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                            ic.setSystemBarsAppearance(dark ? 0 : both, both);
                        }
                    } else {
                        View d = w.getDecorView();
                        int f = d.getSystemUiVisibility();
                        int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | 0x10;
                        d.setSystemUiVisibility(dark ? (f & ~light) : (f | light));
                    }
                }
            });
        }
    }
}
