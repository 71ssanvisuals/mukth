#!/usr/bin/env bash
# يبني APK موقّعًا لتطبيق «رُوَيْد» بأدوات Android SDK الرسمية (دون Gradle)
set -euo pipefail
cd "$(dirname "$0")/.."
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:?Android SDK not found}}"
BT="$SDK/build-tools/$(ls "$SDK/build-tools" | grep -E '^[0-9]+\.[0-9]+\.[0-9]+$' | sort -V | tail -1)"
API=""
for a in 35 36 34; do if [ -f "$SDK/platforms/android-$a/android.jar" ]; then API=$a; break; fi; done
if [ -z "$API" ]; then API="$(ls "$SDK/platforms" | grep -E '^android-[0-9]+$' | sed 's/android-//' | sort -n | tail -1)"; fi
PLAT="$SDK/platforms/android-$API/android.jar"
VC="${VC:-1}"; VN="2.0.${VC}"
echo "build-tools: $BT"; echo "platform/target: android-$API"; echo "version: $VN ($VC)"
[ -f assets/www/data.js ] || bash scripts/fetch_assets.sh
test -f assets/www/tanzil.js
O=build; rm -rf "$O"; mkdir -p "$O/gen" "$O/cls" "$O/dex"
"$BT/aapt2" compile --dir res -o "$O/res.zip"
"$BT/aapt2" link -o "$O/base.apk" -I "$PLAT" --manifest AndroidManifest.xml --java "$O/gen" -A assets \
  --min-sdk-version 24 --target-sdk-version "$API" --version-code "$VC" --version-name "$VN" -0 woff2 "$O/res.zip"
javac -nowarn -source 8 -target 8 -bootclasspath "$PLAT" -d "$O/cls" $(find src/app/ruwayd "$O/gen" -name '*.java')
"$BT/d8" --release --min-api 24 --lib "$PLAT" --output "$O/dex" $(find "$O/cls" -name '*.class')
(cd "$O/dex" && zip -q ../base.apk classes.dex)
"$BT/zipalign" -f -p 4 "$O/base.apk" "$O/aligned.apk"
base64 -d keystore/mukth.jks.b64 > "$O/ks.jks"
"$BT/apksigner" sign --ks "$O/ks.jks" --ks-pass pass:mukth-app --ks-key-alias mukth --out "$O/Ruwayd.apk" "$O/aligned.apk"
"$BT/apksigner" verify --verbose "$O/Ruwayd.apk" > "$O/verify.txt"; head -6 "$O/verify.txt"
"$BT/aapt2" dump badging "$O/Ruwayd.apk" > "$O/badging.txt"; head -3 "$O/badging.txt"
cp "$O/Ruwayd.apk" "$O/Mukth.apk"   # الاسم الذي ينتظره ملف سير العمل الحالي
ls -la "$O"/*.apk
